#!/bin/bash
export UBUNTU_MENUPROXY=0
dir=$(dirname $(readlink -m $0))
if [ "$HOSTTYPE" = "x86_64" ]; then
    $dir/Archi64
else
    $dir/Archi32
fi
